$('.regstats').click(function(){

    window.location.replace("register.php");

})