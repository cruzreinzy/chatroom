<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/reglog.css">
    <link rel="stylesheet" href="assets/css/extra.css">
    <title>ZyChats - Sign Up</title>
</head>
<body class="body">

    <div id="loader3">
        <div><img src="assets/img/loading.gif" alt="Loading"></div>
    </div>

    <main>
    <div class="centered">
        <div class="backggg">
            <div class="topper"><a href="register.php">ZyChats</a></div>

                <div class="regstatus">You've Successfully Registered!</div>

                <form id="">

                    <div class="actbt2">
                        <button type="button" class="register regstats">Go Back</button>
                    </div>

                </form>

        </div>
    </div>

    </main>
    
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/regstatus.js"></script>
</body>
</html>